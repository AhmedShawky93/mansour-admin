export const environment = {
  production: true,
  api: "https://api.misrpharmacy.com/api",
};
