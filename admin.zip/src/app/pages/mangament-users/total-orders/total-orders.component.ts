import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-orders',
  templateUrl: './total-orders.component.html',
  styleUrls: ['./total-orders.component.css']
})
export class TotalOrdersComponent implements OnInit {

  p = 1;

  constructor() { }

  ngOnInit() {
  }

}
