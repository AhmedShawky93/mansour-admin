export class products {
  public  product  = {
        "name": "",
        "description": "",
        "brand_id": "",
        "price":"",
        "discount_price": "",
        "category_id": "",
        "image": "",
        "images": [
        ]
      }
 }
